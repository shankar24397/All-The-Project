# NLP_Disaster_dataset

Operations on text data and standardizing it to process.
