# NLP-Operations
It consists all the basic operations mostly performed while cleaning or dealing with txt data.
