# Data_visualization_pr
Generating random data and visualizing it.
Visualizing data through various graphs & plots.
using libraries: matplotlib & seaborn.
